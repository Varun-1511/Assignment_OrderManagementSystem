
import java.sql.SQLException;
import java.util.List;

import Exception.UserNotFoundException;

public interface IOrderManagementRepository {
    void createOrder(User user, List<Product> products) throws Exception;
    void cancelOrder(int userId, int orderId) throws Exception;
    void createProduct(User user, Product product) throws Exception;
    void createUser(User user) throws Exception; // Adjusted throws clause
    List<Product> getAllProducts() throws Exception; // Adjusted throws clause
    List<Product> getOrderByUser(User user) throws Exception; // Adjusted throws clause
	void createOrder1(User user, List<Product> products) throws SQLException, UserNotFoundException;
}
