import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
    // Database connection parameters
    public static void main(String[] args) {
    	Connection conn=null;
    	try {
    		Class.forName("com.mysql.cj.jdbc.Driver");
    		conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/ordermanagementsystem","root","PHW#84#jeor");
    		System.out.println("Connected to the database");
    	}
    	catch(Exception e)
    	{
    		System.out.println(e);
    	}
    }
}
