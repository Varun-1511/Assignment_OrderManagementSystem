

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

import Exception.OrderNotFoundException;
import Exception.UserNotFoundException;

public class OrderProcessor implements IOrderManagementRepository {
    private Connection connection;
    private Map<Integer, User> userDatabase;
    private Map<Integer, List<Product>> orderDatabase;
    private List<Product> productDatabase;

    public OrderProcessor() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/ordermanagementsystem", "root", "PHW#84#jeor");
            userDatabase = new HashMap<>();
            orderDatabase = new HashMap<>();
            productDatabase = new ArrayList<>();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void createOrder(User user, List<Product> products) throws SQLException {
        try {
            PreparedStatement statement = connection.prepareStatement("INSERT INTO orders (user_id) VALUES (?)", PreparedStatement.RETURN_GENERATED_KEYS);
            statement.setInt(1, user.getUserId());
            statement.executeUpdate();
            ResultSet generatedKeys = statement.getGeneratedKeys();
            int orderId;
            if (generatedKeys.next()) {
                orderId = generatedKeys.getInt(1);
            } else {
                throw new SQLException("Creating order failed, no ID obtained.");
            }

            for (Product product : products) {
                PreparedStatement detailStatement = connection.prepareStatement("INSERT INTO order_details (order_id, product_id) VALUES (?, ?)");
                detailStatement.setInt(1, orderId);
                detailStatement.setInt(2, product.getProductId());
                detailStatement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
    }

    @Override
    public void cancelOrder(int userId, int orderId) throws SQLException, OrderNotFoundException {
        try {
            PreparedStatement statement = connection.prepareStatement("DELETE FROM orders WHERE order_id = ? AND user_id = ?");
            statement.setInt(1, orderId);
            statement.setInt(2, userId);
            int rowsAffected = statement.executeUpdate();
            if (rowsAffected == 0) {
                throw new OrderNotFoundException("Order not found for the specified user.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
    }

    @Override
    public void createProduct(User user, Product product) throws SQLException {
        try {
            PreparedStatement statement = connection.prepareStatement("INSERT INTO products (product_name, description, price, quantity_in_stock, type, brand, size, color, warranty_period) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            statement.setString(1, product.getProductName());
            statement.setString(2, product.getDescription());
            statement.setDouble(3, product.getPrice());
            statement.setInt(4, product.getQuantityInStock());
            statement.setString(5, product.getType());
            statement.setString(6, product instanceof Electronics ? ((Electronics) product).getBrand() : null);
            statement.setString(7, product instanceof Clothing ? ((Clothing) product).getSize() : null);
            statement.setString(8, product instanceof Clothing ? ((Clothing) product).getColor() : null);
            statement.setInt(9, product instanceof Electronics ? ((Electronics) product).getWarrantyPeriod() : 0);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
    }

    @Override
    public void createUser(User user) throws SQLException {
        try {
            PreparedStatement statement = connection.prepareStatement("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");
            statement.setString(1, user.getUsername());
            statement.setString(2, user.getPassword());
            statement.setString(3, user.getRole());
            statement.executeUpdate();
            userDatabase.put(user.getUserId(), user);
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
    }

    @Override
    public List<Product> getAllProducts() throws SQLException {
        try {
            List<Product> products = new ArrayList<>();
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM products");
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                int productId = resultSet.getInt("product_id");
                String productName = resultSet.getString("product_name");
                String description = resultSet.getString("description");
                double price = resultSet.getDouble("price");
                int quantityInStock = resultSet.getInt("quantity_in_stock");
                String type = resultSet.getString("type");
                String brand = resultSet.getString("brand");
                String size = resultSet.getString("size");
                String color = resultSet.getString("color");
                int warrantyPeriod = resultSet.getInt("warranty_period");

                Product product;
                if (type.equals("Electronics")) {
                    product = new Electronics(productId, productName, description, price, quantityInStock, type, brand, warrantyPeriod);
                } else {
                    product = new Clothing(productId, productName, description, price, quantityInStock, type, size, color);
                }
                products.add(product);
            }
            return products;
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
    }

    @Override
    public List<Product> getOrderByUser(User user) throws SQLException {
        try {
            List<Product> orderedProducts = new ArrayList<>();
            PreparedStatement statement = connection.prepareStatement("SELECT p.* FROM products p INNER JOIN order_details od ON p.product_id = od.product_id INNER JOIN orders o ON od.order_id = o.order_id WHERE o.user_id = ?");
            statement.setInt(1, user.getUserId());
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                int productId = resultSet.getInt("product_id");
                String productName = resultSet.getString("product_name");
                String description = resultSet.getString("description");
                double price = resultSet.getDouble("price");
                int quantityInStock = resultSet.getInt("quantity_in_stock");
                String type = resultSet.getString("type");
                String brand = resultSet.getString("brand");
                String size = resultSet.getString("size");
                String color = resultSet.getString("color");
                int warrantyPeriod = resultSet.getInt("warranty_period");

                Product product;
                if (type.equals("Electronics")) {
                    product = new Electronics(productId, productName, description, price, quantityInStock, type, brand, warrantyPeriod);
                } else {
                    product = new Clothing(productId, productName, description, price, quantityInStock, type, size, color);
                }
                orderedProducts.add(product);
            }
            if (orderedProducts.isEmpty()) {
                System.out.println("No products ordered by user with ID " + user.getUserId());
            }
            return orderedProducts;
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
    }
    
    @Override
    public void createOrder1(User user, List<Product> products) throws SQLException, UserNotFoundException {
        try {
            // Check if the user exists in the database
            if (!userDatabase.containsKey(user.getUserId())) {
                throw new UserNotFoundException("User not found in the database. Please create the user first.");
            }

            // If the user exists, proceed to create the order
            PreparedStatement statement = connection.prepareStatement("INSERT INTO orders (user_id) VALUES (?)", PreparedStatement.RETURN_GENERATED_KEYS);
            statement.setInt(1, user.getUserId());
            statement.executeUpdate();
            ResultSet generatedKeys = statement.getGeneratedKeys();
            int orderId;
            if (generatedKeys.next()) {
                orderId = generatedKeys.getInt(1);
            } else {
                throw new SQLException("Creating order failed, no ID obtained.");
            }

            for (Product product : products) {
                PreparedStatement detailStatement = connection.prepareStatement("INSERT INTO order_details (order_id, product_id) VALUES (?, ?)");
                detailStatement.setInt(1, orderId);
                detailStatement.setInt(2, product.getProductId());
                detailStatement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
    }

    }
